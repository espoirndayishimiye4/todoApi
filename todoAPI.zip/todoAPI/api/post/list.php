<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');


  include_once '../../config/Database.php';
  include_once '../../models/Post.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate blog post object
  $post = new Post($db);

  // Blog post query
  $result = $post->read();
  // Get row count
  $num = $result->rowCount();


?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>To Do list</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- DATATABLE STYLE  -->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body background="bg.png">
      <!------MENU SECTION START-->

<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
            <div class="row" style="margin-top:30px">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           To Do List
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                    <tr>
                                    <th>Number</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Priority</th>
                                    <th>Creation Date</th>
                                    <th>Modification Date</th>
                                    <th>Action</th>
                                </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                      // Check if any posts
                                    if($num > 0) {
                                       
                                        //loop to fetch all records
                                        $n=1;

                                        while($row = $result->fetch(PDO::FETCH_ASSOC)) {
                                            ?>

                                            <tr class="odd gradeX">
                                                <td class="center"><?php echo $n; ?></td>
                                                <td class="center"><?php echo $row['Title']; ?></td>
                                                <td class="center"><?php echo $row['Description']; ?></td>
                                                <td class="center"><?php echo $row['Priority']; ?></td>
                                                <td class="center"><?php echo $row['CreationDate']; ?></td>
                                                <td class="center"><?php echo $row['ModifiedDate']; ?></td>
                                                <td class="center"> <a  href="edit.php?edit=<?php echo $row['id'];?>">Edit</a> |  
                                                                    <a  href="../../models/delete.php?delete=<?php echo $row['id'];?>">Delete</a></td>
                                            </tr>
                                        

                                        

                                       <?php $n=$n+1; }

                                        

                                    } else {
                                    echo 'not data';
                                    }
                                    ?>
                                      
                                                                            
                                    </tbody>
                                </table>
                            </div>
 <a href="form.php"><input type="submit" class="btn btn-info" name="print" value="Add Item" > </a> 
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>     
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- DATATABLE SCRIPTS  -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
 
</body>
</html>

