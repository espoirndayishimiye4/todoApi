<?php

include_once '../../config/Database.php';

        // Instantiate DB & connect
        $database = new Database();
        $db = $database->connect();

        //get id from list and select corresponding row in db
      if(isset($_GET['edit']))
      {
         $id=$_GET['edit'];

                    $sql = "SELECT * FROM `todo_items` WHERE id=$id";
                      $query = $db->prepare($sql);
                      $query->execute();
                      $row = $query->fetch(PDO::FETCH_ASSOC);

      }
                                              
          ?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>To Do list</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- DATATABLE STYLE  -->
   
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body background="bg.png">
      <!------MENU SECTION START-->

<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
            <div class="row" style="margin-top:30px">
                <div class="col-md-12">
                <center>
                    <h2>Edit Item  Form</h2>
                   <form action="../../models/edit.php" method='post'>

                   <input type="text" name="id" value="<?php echo $row['id']; ?>" style="display:none;">
                   Title: <input type="text" name="title" id="" value="<?php echo $row['Title']; ?>"> <br><br>
                   Description: <textarea name="description" id="" cols="30" rows="3"><?php echo $row['Description']; ?></textarea> <br><br>
                   Priority: 
                   <select name="priority" id="">
                   <option value="LOW">LOW</option>
                   <option value="MEDIUM">MEDIUM</option>
                   <option value="HIGH">HIGH</option>

                   </select><br><br>
                   <button type="submit" name="submit">Add</button>
                   <button type="reset">Reset</button>
                   </form>
                   </center>
                </div>
            </div>     
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
 
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
 
</body>
</html>

