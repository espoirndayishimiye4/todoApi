# PHP APIs to create, read, update and delete

## installation

1.requirements: working xampp, browser 
2.extract todoAPI folder 
3.create and import database todo_db in database folder 
4.use this link to access list of activity http://localhost/todoAPI/api/post/list.php

### uses of app

1.list of activity displayed
2.you can edit
3.create using add item button at bottom left side
4.delete

# caution 

if connection doesn't work change parameter according to your computer 
in config/database.php 

