 <?php
 //database class
 class Database{
     //database parameters 
     private $host = 'localhost';
     private $db_name = 'todo_db';
     private $username = 'root';
     private $password = ''; 
     private $conn;

     //DB connection function
     public function connect(){
         $this->conn = null;

         try{

            //connection
            $this->conn = new PDO('mysql:host='. $this->host .';dbname='.$this->db_name,$this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 

         } catch(PDOException $e){
             echo 'connection error: '.$e->getMessage(); 
         }
       //return db connection

       return $this->conn;


     }
 }
 ?>