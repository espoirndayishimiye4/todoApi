<?php
include_once '../config/Database.php';

// Instantiate DB & connect
$database = new Database();
$db = $database->connect();

if(isset($_GET['delete']))
{
   $id=$_GET['delete'];

              $sq = "SELECT * FROM `todo_items` WHERE id=$id";
                $query = $db->prepare($sq);
                $query->execute();
                

         
 
     $sql = "DELETE FROM `todo_items` WHERE `todo_items`.`id` = $id";
     $stmt= $db->prepare($sql);
 
     $stmt->execute();
     if ($stmt) {
         echo "<script>alert( 'Activity Deleted!')</script>";

         echo "<script>
         window.open('../api/post/list.php','_self')
         </script>";	
         
     }
}
?>