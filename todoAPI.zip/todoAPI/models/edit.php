<?php
include_once '../config/Database.php';

// Instantiate DB & connect
$database = new Database();
$db = $database->connect();

if (isset($_POST['submit'])) {

         $id = filter_var($_POST['id'], FILTER_SANITIZE_STRING);
         $Title = filter_var($_POST['title'], FILTER_SANITIZE_STRING);
         $Description = filter_var($_POST['description'], FILTER_SANITIZE_STRING);
         $Priority = filter_var($_POST['priority'], FILTER_SANITIZE_STRING);
         
 
     $sql = "UPDATE `todo_items` SET `Title` = '$Title', `Description` = '$Description', `Priority` = '$Priority' WHERE `todo_items`.`id` = $id";
     $stmt= $db->prepare($sql);
 
     $stmt->execute(array(':Title'=>$Title, ':Description'=>$Description,':Priority'=>$Priority));
     if ($stmt) {
         echo "<script>alert( 'activity Edited!')</script>";

         echo "<script>
         window.open('../api/post/list.php','_self')
         </script>";	
         
     }
}
?>