<?php
include_once '../config/Database.php';

// Instantiate DB & connect
$database = new Database();
$db = $database->connect();

if (isset($_POST['submit'])) {


         $Title = filter_var($_POST['title'], FILTER_SANITIZE_STRING);
         $Description = filter_var($_POST['description'], FILTER_SANITIZE_STRING);
         $Priority = filter_var($_POST['priority'], FILTER_SANITIZE_STRING);
         
 
     $sql = "INSERT INTO `todo_items` (`id`, `Title`, `Description`, `Priority`, `CreationDate`, `ModifiedDate`) VALUES (NULL, '$Title', '$Description', '$Priority', CURRENT_TIMESTAMP, '0000-00-00 00:00:00.000000')";
     $stmt= $db->prepare($sql);
 
     $stmt->execute(array(':Title'=>$Title, ':Description'=>$Description,':Priority'=>$Priority));
 
     if ($stmt) {
         echo "<script>alert( 'activity added!')</script>";

         echo "<script>
         window.open('../api/post/list.php','_self')
         </script>";	
         
     }
}
?>